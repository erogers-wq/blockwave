# Blockwave — iPhone PWA

## Files

```
blockwave/
  index.html          the game (also copied as blockwave.html)
  manifest.json       Home Screen metadata
  service-worker.js   offline cache
  icons/
    apple-touch-icon-180.png   180x180  <- the one iOS actually uses
    icon-192.png               192x192
    icon-512.png               512x512
    icon-512-maskable.png      512x512  (Android adaptive)
    icon-1024.png              1024x1024 (App Store / marketing spare)
```

All four required files must sit in the **same folder**, with `icons/` beside
`index.html`. The paths in the manifest and the HTML are relative, so the app
works in a subfolder (`example.com/blockwave/`) as well as at a domain root.

## Putting it online

Any static host over **HTTPS** works. HTTPS is required — iOS will not
register a service worker or offer a proper standalone launch over plain HTTP.

**GitHub Pages**
1. Create a repository, upload the whole folder.
2. Settings → Pages → Deploy from branch → `main` / root.
3. Wait for the green tick, then open `https://<user>.github.io/<repo>/`.

**Netlify (easiest)**
1. Go to app.netlify.com/drop.
2. Drag the whole `blockwave` folder onto the page.
3. It gives you an HTTPS URL immediately.

**Cloudflare Pages / Vercel** — same idea: upload the folder, no build step,
no framework. Output directory is the folder itself.

Opening `index.html` straight off the filesystem (`file://`) still plays the
game and still saves progress; only the service worker is skipped.

## Adding it to an iPhone Home Screen

1. Open the URL in **Safari** (not Chrome — only Safari can install on iOS).
2. Tap the **Share** button (square with an arrow, bottom centre).
3. Scroll and tap **Add to Home Screen**.
4. The name will already read *Blockwave*. Tap **Add**.
5. Launch it from the Home Screen icon. It opens full screen with no Safari
   address bar, and works with no signal after that first load.

To update later: upload the new files, bump `CACHE_VERSION` in
`service-worker.js`, then open the app twice (once to fetch, once to run it).

## Where progress is stored

Everything lives in this browser's `localStorage`, under one key:

```
blockwave_save_v2
```

It holds a single versioned object:

```json
{ "v": 2, "best": 0, "sound": true, "vibe": true, "music": true,
  "xp": 0, "prestige": 0, "levelColor": "white", "theme": "",
  "name": "", "boards": { "daily": {...}, "levels": [...] } }
```

* **On the device only.** Nothing is uploaded and there is no server, so each
  family member's iPhone keeps a completely separate save. One person's best
  score can never overwrite another's.
* **Written immediately** when a run ends, when you prestige, when the app is
  backgrounded, and when it is closed — plus a coalesced write for settings.
* **The best score only ever climbs.** It is stored through a `max()`, so
  starting a new game, resetting settings, or a partial save can never lower it.
* **Corrupt or future-version saves** fall back to defaults instead of
  crashing, and a pre-PWA save is migrated rather than discarded.
* **Erase all progress** in Settings → Data is the only thing that clears it,
  behind a confirmation.

Note: because there is no server, the leaderboards are now per-device — you
see your own runs and ranks, not other people's.
